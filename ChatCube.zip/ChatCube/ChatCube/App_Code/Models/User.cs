﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for User
/// </summary>
public class User
{
    public int User_ID { get; set; }
    public string FirstName { get; set; }
    public string Surname { get; set; }
}